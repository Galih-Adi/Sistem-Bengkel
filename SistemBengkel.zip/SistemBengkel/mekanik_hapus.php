<?php
	include("sess_check.php");
		$id = $_GET['kas'];	
		$sql = "DELETE FROM mekanik WHERE id_mkn='". $id ."'";
		$ress = mysqli_query($conn, $sql);
		header("location: mekanik.php?act=delete&msg=success");
?>