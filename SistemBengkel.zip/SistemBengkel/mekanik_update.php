<?php
	include("sess_check.php");
	
	// query database memperbarui data pada database
	if(isset($_POST['perbarui'])) {
		$id=$_POST['mkn'];
		$nama=$_POST['nama'];
		$telp=$_POST['telp'];
		$alamat=$_POST['alamat'];
		$sql = "UPDATE mekanik SET
				nama_mkn='". $nama ."',
				telp_mkn='". $telp ."',
				alamat_mkn='". $alamat ."'
				WHERE id_mkn='". $id ."'";
		$ress = mysqli_query($conn, $sql);
		header("location: mekanik.php?act=update&msg=success");
	}
?>